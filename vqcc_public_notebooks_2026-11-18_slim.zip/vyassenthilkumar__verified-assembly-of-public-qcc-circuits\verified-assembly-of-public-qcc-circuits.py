# %% [markdown]
# # Verifiable Quantum Circuit Compilation — verified assembly + own gauge descent
#
# This notebook does the two parts of the task that are easy to get wrong in a competition where
# every team publishes circuits faster than anyone can trust a claim about them:
#
# 1. it locates candidate circuits by **SHA-256**, runs the **unmodified official verifiers** on
#    each one, and only builds a submission from parts that pass, ranked by *measured* score;
# 2. it measures the denominator too: the reference cost of every task comes from running the same
#    verifier on the organizers' own `sample_submission/` a few cells earlier, not from a constant;
# 3. it then improves one of them **itself**, with no new circuit at all.
#
# Step 3 is the reason this notebook exists. `dfthcsos` bills `score = lambda_eff * T_total *
# Q_total`, and `T`/`Q` are properties of the submitted `.kmb` circuits, so on a fixed circuit tree
# the only remaining knob is `lambda_eff = sqrt(E_gap * (2*Lambda - E_gap))`. `Lambda` carries the
# column L1 sums of the augmented factor `[w_b ; w_B]`, and each slice may be right-multiplied by
# any orthogonal matrix. Measured on our own factor, that rotation leaves `error_1` and `E_gap`
# **exactly** invariant — they depend on the row space, which a right rotation cannot touch — and
# moves only the L1 term. So the whole budget is `error_2`, and our factor already sits 1.2e-7 Ha
# under its 20 mHa gate.
#
# Every circuit is somebody else's public Apache-2.0 work, attached as data so this notebook never
# depends on a mutable external URL:
#
# | task | what | whose |
# |---|---|---|
# | `invsqrt` | 63-qubit reciprocal-square-root phasing | mrmeows (team selenium), main lookup re-synthesised by busyaprime (Akmal Xodarev) |
# | `dqi` | 889-qubit Reed–Solomon MBUC syndrome decoder | SomeJoint (Agniv Banerjee), widened to 889 qubits by heliosli |
# | `dfthcsos` | 15 five-word ANGLE circuits over 1,220 addresses | heliosli's `qcc-circuits-live` release of the SomeJoint full-XOR (8, 143, 60) family |
# | gauge code | Cayley/CG + Givens descent on the factor orbit | Magmucot / alexchilton `qcc-llm-gauge` (Apache-2.0) |
# | organizers | task definitions, verifiers, kickmix | Google Quantum AI / Qualtran |
#
# What is ours: the descended weights, the schedule that spends them, and every number printed
# below. The circuits are not.

# %% Discover the mounted competition data and make `kickmix` importable.
import hashlib
import json
import lzma
import math
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

INPUT = Path(os.environ.get('QCC_INPUT', '/kaggle/input'))
WORK = Path(os.environ.get('QCC_WORK', '/kaggle/working'))


def find(name, *, directory=False):
    hits = [p for p in INPUT.rglob(name) if (p.is_dir() if directory else p.is_file())]
    if not hits:
        raise FileNotFoundError(f'{name} not present under {INPUT}')
    return hits[0]


VERIFIERS = find('verifiers', directory=True)
KICKMIX = find('kickmix.so').parent
os.environ['PYTHONPATH'] = str(KICKMIX)
print('verifiers :', VERIFIERS)
print('kickmix   :', KICKMIX)
print('python    :', sys.version)
subprocess.run([sys.executable, '-c', 'import kickmix, sys; '
                'print("kickmix OK", kickmix.__file__)'], env=os.environ, check=True)

# %% Pin every byte by content, never by path. Two independent sources of truth are used: the three
# digests this notebook was written against, and the release manifest that ships inside the dataset.
# A file is only ever placed after its own hash has been checked, which is why an attachment that
# changes underneath the notebook fails loudly here instead of becoming a rejected submission - the
# earlier version of this file did exactly that, and the grader caught it as
# "ANGLE_10 does not use the same 'selection' register as ANGLE_0".
EXPECTED = {
    'invsqrt.kmb': '07314803a0925970cf45007ebbdb8a146378c242e3991c70d6f7509af3d583da',
    'dqi.kmb': '4ee7a17b4cbca4053a19bc951e7f2ef91fabdbb036006c9d658adcff4fe76da4',
    'dfthcsos/submission.npz': 'aef36d39b83bbbf696e909884218f6c02f067baef14a29de1c41306bc1f6395b',
}
ANGLE_COUNT = 15


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for block in iter(lambda: fh.read(1 << 22), b''):
            h.update(block)
    return h.hexdigest()


# The manifest supplies the 15 ANGLE circuits that the three constants above cannot cover: the tree
# is only legal if the circuits match the npz they were generated from, byte for byte.
manifests = sorted(INPUT.rglob('QCC_RELEASE_MANIFEST.json'))
pins = dict(EXPECTED)
if manifests:
    entries = json.loads(manifests[0].read_text())['files']
    for e in entries:
        pins[e['file']] = e['sha256']
    disagree = {k: (pins.get(k), v) for k, v in EXPECTED.items() if pins.get(k) != v}
    if disagree:
        raise SystemExit(
            'the attached release no longer matches the digests this notebook was written against:\n'
            + '\n'.join(f'  {k}: manifest {m[:16]}... vs notebook {e[:16]}...'
                        for k, (m, e) in sorted(disagree.items()))
            + '\nA portfolio must be assembled from one coherent release, so nothing is built. '
              'Re-pin EXPECTED to the new manifest and re-verify before submitting.')
    print(f'manifest {manifests[0]}: {len(entries)} entries, agrees with the pinned digests')
else:
    print('no release manifest attached; falling back to the three pinned digests')

by_name = {}
for p in INPUT.rglob('*'):
    if p.is_file():
        by_name.setdefault(p.name, []).append(p)

STAGE = WORK / 'base'
if STAGE.exists():
    shutil.rmtree(STAGE)
STAGE.mkdir(parents=True)

placed = []
for logical, digest in sorted(pins.items()):
    # `qcc-circuits-live` stores its chemistry tree flat, as dfthcsos__<file>, and dqi as .xz.
    names = [logical.replace('/', '__'), Path(logical).name]
    names += [n + '.xz' for n in names]
    hit = None
    for n in dict.fromkeys(names):
        for cand in by_name.get(n, ()):
            dest = STAGE / logical
            dest.parent.mkdir(parents=True, exist_ok=True)
            if n.endswith('.xz'):
                with lzma.open(cand) as src, open(dest, 'wb') as out:
                    shutil.copyfileobj(src, out, 1 << 22)
            else:
                shutil.copyfile(cand, dest)
            if sha256(dest) == digest:
                hit = cand
                break
            dest.unlink(missing_ok=True)
        if hit:
            break
    if hit is None:
        raise FileNotFoundError(f'nothing under {INPUT} hashes to {digest[:16]}... for {logical}; '
                                'the attached dataset version no longer carries it - do not build.')
    placed.append((logical, hit))

angles = sorted((STAGE / 'dfthcsos').glob('angle_k_*.kmb'))
assert len(angles) == ANGLE_COUNT, [p.name for p in angles]
for logical, src in placed:
    print(f'{logical:26s} {pins[logical][:16]}...  <- {src}')

# %% Where does the denominator come from? Nowhere near a number I typed. The organizers ship their
# own baseline in `sample_submission/`, so the reference cost of each task is measured here, by the
# same unmodified verifier, on the same machine, one cell before our own circuits are measured. The
# documented constants below are only a cross-check on that measurement.
SAMPLE = find('sample_submission', directory=True)
DOC_REF = {
    'invsqrt': 2076774.233715282,      # dfthcsos/SCORING_README.md and the task READMEs
    'dqi': 24439463583672.93,
    'dfthcsos': 3355599588.3155365,
}
REF_SRC = {k: 'documented' for k in DOC_REF}
REF = dict(DOC_REF)

REF_CMDS = {
    'invsqrt': [sys.executable, str(VERIFIERS / 'invsqrt' / 'verify_submission_invsqrt.py'),
                str(SAMPLE / 'invsqrt.kmb')],
    'dqi': [sys.executable, str(VERIFIERS / 'dqi' / 'verify_submission_dqi.py'), str(SAMPLE / 'dqi.kmb')],
    'dfthcsos': [sys.executable, str(VERIFIERS / 'dfthcsos' / 'verify.py'), str(SAMPLE / 'dfthcsos')],
}
for task, argv in REF_CMDS.items():
    if not Path(argv[-1]).exists():
        print(f'{task}: no shipped sample at {argv[-1]}; keeping the documented reference')
        continue
    proc = subprocess.run(argv, capture_output=True, text=True, env=os.environ)
    try:
        measured = json.loads(proc.stdout).get('score')
    except Exception:
        measured = None
    if measured and abs(measured / DOC_REF[task] - 1) < 1e-3:
        REF[task], REF_SRC[task] = measured, 'measured here'
    print(f'{task:10s} reference {REF[task]:>22,.4f}  ({REF_SRC[task]}; verifier said {measured})')

# %% Descend the gauge on our factor, scored by the organizers' own metric evaluator.
# `evaluate_dfthc_angle_words` is the function the verifier calls to produce `error_1`, `error_2`,
# `Lambda`, `E_gap` and `lambda_eff`, so it is an exact oracle at ~2 s instead of a full circuit
# run. Mind the coordinate conversion the verifier performs first: the npz stores lowercase w as
# `W` and `w_B = W + sum_b w` as `H2_I`, so the native offset row is `H2_I - sum_b W`.
sys.path.insert(0, str(find('gemini_gauge.py').parent))
# `dfthcsos` is the verifier's own package, i.e. VERIFIERS/dfthcsos. The local shell run only worked
# because the process was started with `verifiers` as its working directory.
sys.path.insert(0, str(VERIFIERS))
import gemini_gauge
from dfthcsos.scoreinfra import reference
from dfthcsos.scoreinfra.dfthc_math import evaluate_dfthc_angle_words, symmetric_from_lower

params = {k: v for k, v in np.load(STAGE / 'dfthcsos' / 'submission.npz', allow_pickle=False).items()}
params.update(reference.load_fixed_shifts())
ref = reference.load_reference(reference.check_fcidump())
S = np.asarray(symmetric_from_lower(params['Hsym_lower'], np.shape(params['U'])[-1]), dtype=np.float64)
beta_1 = float(params['H1_I']) - 0.5 * float(np.trace(S))
words, edges, brot = params['angle_words'], params['tree_edges'], int(params['brot'])
a0 = np.concatenate([np.asarray(params['W'], np.float64),
                     np.asarray(params['H2_I'], np.float64)[:, None, :]], axis=1)
gram0 = a0 @ a0.swapaxes(1, 2)

E1_CAP, E2_CAP = 0.019995, 0.0199995      # gates are <= 0.020; equality fails, and e2 has 1.2e-7
LAMBDA_FLOOR, GAP_FLOOR = 49.0, 3.914898  # strict floors from dfthcsos/verify.py


def metrics(a):
    w = a[:, :-1, :]
    return evaluate_dfthc_angle_words(words, w, a[:, -1, :] - w.sum(axis=1), S, beta_1, ref,
                                      brot=brot, tree_edges=edges,
                                      energy_upper=reference.UPPER_ENERGY)


def ok(m):
    return (m['error_1'] <= E1_CAP and m['error_2'] <= E2_CAP and m['Lambda'] > LAMBDA_FLOOR
            and m['E_gap'] > GAP_FLOOR and np.isfinite(m['lambda_eff']))


def orth_interp(a_start, a_end, t):
    """Geodesic retreat: a_end = a_start @ Q slice-wise, return a_start @ Q**t."""
    out = a_start.copy()
    for s in range(a_start.shape[0]):
        Q = np.linalg.lstsq(a_start[s], a_end[s], rcond=None)[0]
        wv, V = np.linalg.eig(Q)
        out[s] = a_start[s] @ np.real(V @ np.diag(np.exp(t * np.log(wv + 0j))) @ np.linalg.inv(V))
    return out


base = metrics(a0)
print('start   lam=%.10f Lambda=%.6f E_gap=%.8f e1=%.7f e2=%.7f  cost=%.0f'
      % (base['lambda_eff'], base['Lambda'], base['E_gap'], base['error_1'], base['error_2'],
         base['lambda_eff'] * 16306 * 430))

best_a, best_m, history = a0.copy(), base, []
for rnd, (iters, sweeps) in enumerate([(120, 25), (60, 200), (30, 400), (10, 600)], start=1):
    t0 = time.monotonic()
    cand = gemini_gauge.givens_coordinate_descent(
        gemini_gauge.optimise_gauge(best_a.copy(), iters)[0], max_sweeps=sweeps)
    drift = float(np.max(np.abs(cand @ cand.swapaxes(1, 2) - gram0)))
    m = metrics(cand)
    row = dict(round=rnd, iters=iters, sweeps=sweeps, seconds=round(time.monotonic() - t0, 1),
               lam=m['lambda_eff'], e2=m['error_2'], drift=drift, feasible=ok(m), accepted=False)
    if ok(m) and drift < 1e-8 and m['lambda_eff'] < best_m['lambda_eff']:
        best_a, best_m, row['accepted'] = cand, m, True
    else:
        for t in (0.9, 0.75, 0.6, 0.45, 0.3, 0.2, 0.1, 0.05):
            retreat = orth_interp(best_a, cand, t)
            mt = metrics(retreat)
            if (ok(mt) and mt['lambda_eff'] < best_m['lambda_eff']
                    and np.max(np.abs(retreat @ retreat.swapaxes(1, 2) - gram0)) < 1e-8):
                best_a, best_m = retreat, mt
                row.update(accepted=True, retreated_to=t)
                break
    history.append(row)
    print(json.dumps(row, default=float))
    if not row['accepted']:
        break

drift = float(np.max(np.abs(best_a @ best_a.swapaxes(1, 2) - gram0)))
print('gauge   lam %.10f -> %.10f (%.4f%%)  Lambda %.6f -> %.6f  e2 %.8f  gram drift %.2e'
      % (base['lambda_eff'], best_m['lambda_eff'],
         100 * (best_m['lambda_eff'] / base['lambda_eff'] - 1),
         base['Lambda'], best_m['Lambda'], best_m['error_2'], drift))
gauged_ok = drift < 1e-8 and ok(best_m) and best_m['lambda_eff'] < base['lambda_eff']
print('gauged factor usable:', gauged_ok)

# %% Write the descended factor as the candidate tree. Only W and H2_I change: angle_words,
# tree_edges, brot, U, H1_I and Hsym_lower stay byte-identical, which is what keeps the submitted
# .kmb circuits legal. If the descent produced nothing usable the candidate tree is simply the
# pinned one, so the notebook still ends with a verified submission.
CAND = WORK / 'cand'
if CAND.exists():
    shutil.rmtree(CAND)
shutil.copytree(STAGE, CAND)
if gauged_ok:
    out = dict(np.load(CAND / 'dfthcsos' / 'submission.npz', allow_pickle=False))
    out['W'] = np.ascontiguousarray(best_a[:, :-1, :], dtype=np.float64)
    out['H2_I'] = np.ascontiguousarray(best_a[:, -1, :], dtype=np.float64)
    assert np.array_equal(out['angle_words'], params['angle_words'])
    assert np.array_equal(out['tree_edges'], params['tree_edges'])
    np.savez(CAND / 'dfthcsos' / 'submission.npz', **out)
    print('candidate npz', sha256(CAND / 'dfthcsos' / 'submission.npz')[:16])
else:
    print('candidate npz unchanged from the pinned release')

# %% Run the official verifiers, unmodified. This is the only authoritative step: it simulates the
# circuits, bills T and Q, and applies the grader's gates. The evaluator above is necessary but not
# sufficient, so the descended tree is adopted only if it survives the real thing - and if it does
# not, the notebook falls back to the pinned public tree instead of shipping nothing.
def run_verifier(task, path):
    argv = {
        'invsqrt': [sys.executable, str(VERIFIERS / 'invsqrt' / 'verify_submission_invsqrt.py'), str(path)],
        'dqi': [sys.executable, str(VERIFIERS / 'dqi' / 'verify_submission_dqi.py'), str(path)],
        'dfthcsos': [sys.executable, str(VERIFIERS / 'dfthcsos' / 'verify.py'), str(path)],
    }[task]
    t0 = time.monotonic()
    proc = subprocess.run(argv, capture_output=True, text=True, env=os.environ)
    try:
        receipt = json.loads(proc.stdout)
    except Exception:
        receipt = {'status': 'CRASH', 'stdout': proc.stdout[-2000:], 'stderr': proc.stderr[-2000:]}
    print(f'  {task:10s} {receipt.get("status")} {receipt.get("score")} '
          f'[{time.monotonic() - t0:.0f}s]', flush=True)
    return receipt


# Only W and H2_I differ between the two trees, so the two untouched circuits are billed once and
# shared - re-running them would double the wall time for a receipt that cannot change.
shared = {t: run_verifier(t, STAGE / f'{t}.kmb') for t in ('invsqrt', 'dqi')}
chemistry = {'pinned public': run_verifier('dfthcsos', STAGE / 'dfthcsos')}
if gauged_ok:
    chemistry['gauged'] = run_verifier('dfthcsos', CAND / 'dfthcsos')
tree_of = {'pinned public': STAGE, 'gauged': CAND}

adopted = None
for label in ('gauged', 'pinned public'):
    if label not in chemistry:
        continue
    results = {**shared, 'dfthcsos': chemistry[label]}
    failed = [t for t, r in results.items() if r.get('status') != 'PASS']
    if failed:
        print(json.dumps({t: results[t] for t in failed}, indent=2)[:4000])
        print(f'{label} tree rejected on {failed}; falling back')
        continue
    ratios = {t: REF[t] / results[t]['score'] for t in REF}
    gm = math.exp(sum(math.log(v) for v in ratios.values()) / 3)
    print(f'{label}: geometric mean {gm:.5f}x')
    if adopted is None or gm > adopted[2]:
        adopted = (tree_of[label], results, gm, ratios, label)

if adopted is None:
    raise SystemExit('no tree passed all three verifiers; not building a submission.')
root, results, gm, ratios, label = adopted

print(f'{"task":10s} {"score":>22s} {"ratio":>9s}   key resources')
for t in ('invsqrt', 'dqi', 'dfthcsos'):
    r = results[t]
    keys = [k for k in ('num_qubits', 'toffoli_count', 'lambda_eff', 'repetition_factor') if k in r]
    print(f'{t:10s} {r["score"]:>22,.2f} {ratios[t]:>8.3f}x   ' +
          '  '.join(f'{k}={r[k]:,.4f}' for k in keys))
print(f'\nadopted tree: {label}   geometric mean ratio = {gm:.5f}x   (the sample scores 1.0)')

# %% Build the artifact the leaderboard accepts. The uploaded file must be named `submission.zip`;
# anything else is rejected by CreateSubmission regardless of contents.
zip_path = WORK / 'submission.zip'
if zip_path.exists():
    zip_path.unlink()
shutil.make_archive(str(zip_path.with_suffix('')), 'zip', root_dir=root)
print(f'{zip_path} = {zip_path.stat().st_size:,} bytes')
print(json.dumps({'gm': gm, 'adopted': label, 'reference': REF, 'reference_source': REF_SRC,
                  'ratios': ratios, 'history': history,
                  'scores': {t: results[t]['score'] for t in results}}, indent=2, default=float))

# %% [markdown]
# ### Honest scope
#
# `T` and `Q` come from circuits we did not design, and `invsqrt`/`dqi` are unchanged from the
# public frontier: `manwithacat/vqcc-apache-public-circuits` re-ran the official verifiers over 60
# public Apache-2.0 artifacts and these same three files rank first in all three tasks, so nothing
# published beats them. What this notebook adds is the chemistry factor — the descended
# `lambda_eff` is ours, gated by the organizers' own thresholds, and the receipts printed above are
# the evidence. The grader merges a secret salt into the seed, so expect small differences in `T`;
# the chemistry errors above do not depend on the salt because the angle words are unchanged.
