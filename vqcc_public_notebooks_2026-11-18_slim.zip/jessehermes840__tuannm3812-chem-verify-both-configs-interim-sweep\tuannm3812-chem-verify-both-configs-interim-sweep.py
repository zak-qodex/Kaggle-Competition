#!/usr/bin/env python3
import subprocess
import sys
import os
import glob
import shutil
import site

# First, set up kickmix module BEFORE installing kickmix-engine
kickmix_so_src = "/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation/kickmix/kickmix.so"
site_packages = site.getsitepackages()[0]
kickmix_pkg_dir = os.path.join(site_packages, "kickmix")
os.makedirs(kickmix_pkg_dir, exist_ok=True)
shutil.copy2(kickmix_so_src, os.path.join(kickmix_pkg_dir, "kickmix.so"))

# Create __init__.py that loads the C++ module - export all needed attributes
with open(os.path.join(kickmix_pkg_dir, "__init__.py"), "w") as f:
    f.write("""
from .kickmix import Circuit, CircuitBuilder, GF2Field, OperationStatistics, Simulator, UnaryIterationCursor, array, b, q, r, xb, xbool
__all__ = ['Circuit', 'CircuitBuilder', 'GF2Field', 'OperationStatistics', 'Simulator', 'UnaryIterationCursor', 'array', 'b', 'q', 'r', 'xb', 'xbool']
""")

# Now install the wheel
wheel_paths = glob.glob("/kaggle/input/datasets/jessehermes840/tuannm3812-chem-screen-both-configs/*.whl")
print(f"Wheel paths found: {wheel_paths}")

if wheel_paths:
    subprocess.run([sys.executable, "-m", "pip", "install", wheel_paths[0]], check=True)

# Test import
try:
    import kickmix
    print(f"kickmix imported successfully: {dir(kickmix)}")
except Exception as e:
    print(f"kickmix import failed: {e}")
    sys.exit(1)

# Config directories (point to dfthcsos subdirectory)
as_shipped = "/kaggle/input/datasets/jessehermes840/tuannm3812-chem-screen-both-configs/tuannm3812_chem_as_shipped/dfthcsos"
bank_loaders = "/kaggle/input/datasets/jessehermes840/tuannm3812-chem-screen-both-configs/tuannm3812_chem_on_bank_loaders/dfthcsos"

print(f"As-shipped config: {as_shipped}")
print(f"Bank-loaders config: {bank_loaders}")

if not os.path.exists(as_shipped) or not os.path.exists(bank_loaders):
    print("Config directories not found")
    sys.exit(1)

# Use competition verifier
verifier = "/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation/verifiers/dfthcsos/verify.py"

# Config 1: as-shipped (tuannm3812 loaders + tuannm3812 npz)
print("=== CONFIG 1: as-shipped (tuannm3812 loaders + tuannm3812 npz) ===")
for salt in [None, 2]:
    cmd = ["kickmix-engine", "verify", "dfthcsos", as_shipped, "--verifier", verifier, "--threads", "2"]
    if salt is not None:
        cmd.extend(["--salt", str(salt)])
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(f"Salt {salt if salt else 'default'}:")
    print(result.stdout)
    if result.stderr:
        print(f"  STDERR: {result.stderr}")

print()

# Config 2: bank-loaders (our bank loaders + tuannm3812 npz)
print("=== CONFIG 2: bank-loaders (our loaders + tuannm3812 npz) ===")
for salt in [None, 2]:
    cmd = ["kickmix-engine", "verify", "dfthcsos", bank_loaders, "--verifier", verifier, "--threads", "2"]
    if salt is not None:
        cmd.extend(["--salt", str(salt)])
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(f"Salt {salt if salt else 'default'}:")
    print(result.stdout)
    if result.stderr:
        print(f"  STDERR: {result.stderr}")
