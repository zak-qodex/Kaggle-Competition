# Re-verify the public mix with the unmodified official verifiers and write submission.zip.
# Candidate mix 2026-11-18 (junmiaotiao combo W measures 28.18965 for these bytes):
#   invsqrt 864f81cd20489d80 — 44 qubits, cost 74490.95
#   dqi 5f901c556cafd02d — 890 qubits, zero-error cost 3.46404e11
#   dfthcsos — npz 4d63be3d5c26cfa4, angle_k_0 ed6487084d30b0c7, cost 294642170.57
# Previous floor 28.18070 (submission 58471500): invsqrt 563d0583, dqi 575b043f, npz 703843d3.
import glob, hashlib, json, math, os, shutil, sys, time, zipfile
from pathlib import Path
COMP = Path('/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation')
if not COMP.exists():
    COMP = Path(next(iter(glob.glob('/kaggle/input/**/google-verifiable-quantum-circuit-compilation', recursive=True))))
sys.path[:0] = [str(COMP / 'kickmix'), str(COMP / 'verifiers')]
import kickmix as km
from invsqrt import verify_submission_invsqrt as vinv
from dqi import verify_submission_dqi as vdqi
from dfthcsos import verify as vdft
REF = {'invsqrt': 2076774.233715282, 'dfthcsos': 3355599588.3155375, 'dqi': 24439463583672.93}
SALT = 'notebook-verification'
W = Path('/kaggle/working/sub'); shutil.rmtree(W, ignore_errors=True); W.mkdir(parents=True)
# Only the combo dataset. A broader glob also matches baseline submission.zip files in other inputs.
hits = glob.glob('/kaggle/input/**/vqcc-combo-candidates/**/invsqrt.kmb', recursive=True)
if not hits:
    raise SystemExit('vqcc-combo-candidates not mounted')
src = Path(hits[-1]).parent
print('using', src)
if (src / 'submission.zip').is_file() and not (src / 'dqi.kmb').is_file():
    zipfile.ZipFile(src / 'submission.zip').extractall(W)
else:
    shutil.copytree(src, W, dirs_exist_ok=True)
def sha16(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()[:16]
expect = {
    'invsqrt.kmb': '864f81cd20489d80',
    'dqi.kmb': '5f901c556cafd02d',
    'dfthcsos/submission.npz': '4d63be3d5c26cfa4',
    'dfthcsos/angle_k_0.kmb': 'ed6487084d30b0c7',
}
for rel, prefix in expect.items():
    got = sha16(W / rel)
    print(rel, got)
    assert got == prefix, f'unexpected {rel}; refusing to verify the wrong portfolio'
print(sorted(p.name for p in W.rglob('*') if p.is_file())[:24])
res = {}
t = time.time(); c = km.Circuit.from_file(str(W / 'invsqrt.kmb'), format='kmb')
res['invsqrt'] = vinv.verify(c, vinv.ProblemSpecInvSqrt.for_n_p(10), salt=SALT); print('invsqrt', round(time.time() - t), 's', flush=True)
t = time.time(); c = km.Circuit.from_file(str(W / 'dqi.kmb'), format='kmb')
res['dqi'] = vdqi.verify(c, vdqi.ProblemSpecDQI.benchmark_instance(), salt=SALT); del c; print('dqi', round(time.time() - t), 's', flush=True)
res['dfthcsos'] = vdft.verify(str(W / 'dfthcsos'), salt=SALT)
orig = glob.glob('/kaggle/input/**/marculera_original_submission.npz', recursive=True)
if orig:
    alt = Path('/kaggle/working/alt'); shutil.rmtree(alt, ignore_errors=True); shutil.copytree(W / 'dfthcsos', alt)
    shutil.copy(orig[0], alt / 'submission.npz')
    try:
        r = vdft.verify(str(alt), salt=SALT); print('chem original weights:', r['status'], r['score'], REF['dfthcsos'] / r['score'])
    except Exception as e:
        print('chem original weights FAIL', e)
ratios = []
for k in ('invsqrt', 'dqi', 'dfthcsos'):
    r = res[k]; print(k, r['status'], float(r['score']), REF[k] / float(r['score']),
                      {x: r.get(x) for x in ('num_qubits', 'lambda_eff', 'toffoli_count', 'value_errors', 'phase_errors') if x in r}, flush=True)
    assert r['status'] == 'PASS'
    ratios.append(REF[k] / float(r['score']))
gm = math.prod(ratios) ** (1 / 3)
print('GEOMETRIC MEAN', gm, 'on salt', SALT)
print('junmiaotiao combo W measures 28.18965 for these exact bytes; our previous floor was 28.18070 (submission 58471500).')
print('This notebook salt can fail one DQI shot and print a lower mean than the leaderboard draw.')
with zipfile.ZipFile('/kaggle/working/submission.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(W.rglob('*')):
        if not p.is_file():
            continue
        rel = str(p.relative_to(W))
        if rel in ('invsqrt.kmb', 'dqi.kmb') or (rel.startswith('dfthcsos/') and p.suffix in ('.kmb', '.npz')):
            z.write(p, rel)
shutil.rmtree(W); shutil.rmtree('/kaggle/working/alt', ignore_errors=True)
print('wrote submission.zip')
