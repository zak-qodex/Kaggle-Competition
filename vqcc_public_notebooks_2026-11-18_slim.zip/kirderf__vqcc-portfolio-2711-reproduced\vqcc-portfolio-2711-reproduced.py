# VQCC portfolio submission - LB 27.11056 (best public assembly, 2026-11-13)
#
# Members and credits:
# - invsqrt.kmb: Syed Asad Ali's 46-qubit inverse-square-root circuit,
#   "VQCC Own-Circuit Portfolio" v12 (Apache-2.0). Unmodified.
#   https://www.kaggle.com/datasets/syed3000/vqcc-own-circuit-portfolio
# - dqi.kmb: Syed Asad Ali's v12 DQI decoder source rebuilt at extractor
#   cutoff 18 (Ertugrul Ozer's cutoff idea) + Areeb Ali's retained-product
#   rewrite (Apache-2.0). Unmodified.
#   https://www.kaggle.com/code/areebbb/qai-fewer-toffolis-same-qubits-lb-27-11042
# - dfthcsos/*: maoxin123 coded-word (8,143,44) DF-THC table, 4,057-Toffoli
#   loaders (CC0-1.0) + prvsiyan's W/H2_I refit (Apache-2.0).
#   https://www.kaggle.com/datasets/prvsiyan/vqcc-verified-best-of-circuits-1106a
#
# This notebook verifies every member sha256 against vqcc_manifest.json and
# writes /kaggle/working/submission.zip with the required 18-member layout.
import hashlib, json, os, zipfile


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


root = next((r for r, _, files in os.walk('/kaggle/input') if 'vqcc_manifest.json' in files), None)
assert root, 'vqcc_manifest.json not found under /kaggle/input'
with open(os.path.join(root, 'vqcc_manifest.json')) as f:
    manifest = json.load(f)

out = '/kaggle/working/submission.zip'
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for member, m in sorted(manifest['members'].items()):
        path = os.path.join(root, m['file'])
        got = sha256(path)
        assert got == m['sha256'], f'{member}: sha256 {got} != manifest {m["sha256"]}'
        z.write(path, member)
        print(member, got)
print(json.dumps({'submission': out, 'sha256': sha256(out)}))
