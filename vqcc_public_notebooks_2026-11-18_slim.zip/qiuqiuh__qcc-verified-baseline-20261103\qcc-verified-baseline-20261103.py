"""Re-verify public portfolio using unchanged official verifiers.

Assembly adapted from heliosli/the-dataset-is-public-now-enjoy, Apache-2.0.
All circuit credits and terms are retained from the attached public dataset.
This kernel never submits automatically to the competition.
"""
import gc
import hashlib
import json
import lzma
import math
import pathlib
import shutil
import sys
import time
import zipfile

WORK = pathlib.Path('/kaggle/working')
COMP = next(p.parent for p in pathlib.Path('/kaggle/input').rglob('verifiers') if p.is_dir())
DS = next(pathlib.Path('/kaggle/input').rglob('QCC_RELEASE_MANIFEST.json')).parent
sys.path[:0] = [str(COMP / 'kickmix'), str(COMP / 'verifiers')]
import kickmix as km
from invsqrt import verify_submission_invsqrt as vi
from dqi import verify_submission_dqi as vq
from dfthcsos import verify as vc


def dump(name, data):
    (WORK / name).write_text(json.dumps(data, indent=2, default=str))


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(4 << 20), b''): h.update(chunk)
    return h.hexdigest()


def main():
    manifest = json.loads((DS / 'QCC_RELEASE_MANIFEST.json').read_text())
    assert manifest['portfolio'] == 'v59_c40h14892y4', 'Public dataset changed: re-review before use'
    sub = WORK / 'candidate'
    sub.mkdir(exist_ok=False)
    for item in manifest['files']:
        target = (sub / item['file']).resolve()
        assert target.is_relative_to(sub.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        source = DS / item['stored_as']
        if source.suffix == '.xz':
            with lzma.open(source) as fi, target.open('wb') as fo: shutil.copyfileobj(fi, fo, 4 << 20)
        else: shutil.copyfile(source, target)
        assert digest(target) == item['sha256'], item['file']
    for name in ('CREDITS.md', 'LICENSE.md', 'QCC_RELEASE_MANIFEST.json'):
        shutil.copyfile(DS / name, WORK / name)
    # Preserve source snapshot: all verifier code is from the competition mount.
    with zipfile.ZipFile(WORK / 'verifier_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for path in (COMP / 'verifiers').rglob('*.py'): z.write(path, str(path.relative_to(COMP)))
    receipt = {'portfolio': manifest['portfolio'], 'salt': manifest['salt'],
               'scope': 'official full default shots; local salt, not Kaggle private salt',
               'reference_costs': manifest['reference_costs'], 'results': {}}
    for task in ('invsqrt', 'dqi', 'dfthcsos'):
        start = time.monotonic()
        if task == 'dfthcsos': result = vc.verify(str(sub / task), salt=manifest['salt'])
        else:
            circuit = km.Circuit.from_file(str(sub / f'{task}.kmb'), format='kmb')
            if task == 'invsqrt': result = vi.verify(circuit, vi.ProblemSpecInvSqrt.for_n_p(10), salt=manifest['salt'])
            else: result = vq.verify(circuit, vq.ProblemSpecDQI.benchmark_instance(), salt=manifest['salt'])
            del circuit
            gc.collect()
        receipt['results'][task] = result
        receipt['results'][task]['wall_seconds'] = time.monotonic() - start
        dump('verification_receipt.json', receipt)
        print(task, json.dumps(result, default=str), flush=True)
        assert result['status'] == 'PASS', (task, result)
    receipt['estimated_score_local_salt'] = math.prod(manifest['reference_costs'][k] / receipt['results'][k]['score'] for k in receipt['results']) ** (1 / 3)
    with zipfile.ZipFile(WORK / 'submission.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for item in manifest['files']: z.write(sub / item['file'], item['file'])
    receipt['submission_sha256'] = digest(WORK / 'submission.zip')
    dump('verification_receipt.json', receipt)
    print('COMPLETE', receipt['estimated_score_local_salt'], flush=True)
    # Retain only the ZIP for the large decoder to avoid duplicating saved output.
    shutil.rmtree(sub)


if __name__ == '__main__': main()
