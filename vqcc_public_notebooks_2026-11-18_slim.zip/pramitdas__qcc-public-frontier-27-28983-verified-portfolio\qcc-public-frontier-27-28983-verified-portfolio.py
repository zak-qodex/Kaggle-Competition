# QCC public frontier 27.28983 - verified portfolio
# Kaggle notebook: verifies every published member against SHA256SUMS and
# rebuilds submission.zip with exactly the submitted layout. No internet needed.

import hashlib
import os
import shutil
import zipfile

WORK = "/kaggle/working"
REBUILT = os.path.join(WORK, "submission.zip")

# Discover the mounted dataset directory (Kaggle may use a slightly different slug).
print("INPUT DIRS:", sorted(os.listdir("/kaggle/input")) if os.path.isdir("/kaggle/input") else "NO INPUT")
DATASET = None
# search recursively for SHA256SUMS
for rootdir, dirs, files in os.walk("/kaggle"):
    if "SHA256SUMS" in files:
        DATASET = rootdir
        break
if DATASET is None:
    # fallback: find any submission.zip
    for rootdir, dirs, files in os.walk("/kaggle"):
        if "submission.zip" in files:
            DATASET = rootdir
            break
assert DATASET is not None, "no dataset found under /kaggle"
print("dataset dir:", DATASET)
print("dataset files:", sorted(os.listdir(DATASET)))

sums = {}
with open(os.path.join(DATASET, "SHA256SUMS")) as fh:
    for line in fh:
        line = line.strip()
        if not line:
            continue
        digest, path = line.split(None, 1)
        sums[path.lstrip("./")] = digest
print(f"manifest entries: {len(sums)}")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


archive = os.path.join(DATASET, "submission.zip")
if os.path.isfile(archive):
    print("using stored archive:", archive, os.path.getsize(archive), "bytes")
    with zipfile.ZipFile(archive) as zf:
        print("archive members:", len(zf.namelist()))
        assert zf.testzip() is None
        zf.extractall(os.path.join(WORK, "verify"))
    root = os.path.join(WORK, "verify")
else:
    print("no submission.zip in dataset; using extracted files")
    root = DATASET
    if os.path.isdir(os.path.join(DATASET, "submission")):
        root = os.path.join(DATASET, "submission")

bad = []
missing = []
for rel, expected in sorted(sums.items()):
    path = os.path.join(root, rel)
    if not os.path.isfile(path):
        missing.append(rel)
        continue
    got = sha256(path)
    if got != expected:
        bad.append((rel, got, expected))
print("missing:", missing)
print("hash mismatches:", bad[:5], "count", len(bad))
assert not missing and not bad
print("ALL 18 MEMBER HASHES VERIFIED")

if os.path.exists(REBUILT):
    os.remove(REBUILT)
with zipfile.ZipFile(REBUILT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    zf.write(os.path.join(root, "invsqrt.kmb"), "invsqrt.kmb")
    zf.write(os.path.join(root, "dqi.kmb"), "dqi.kmb")
    for name in sorted(os.listdir(os.path.join(root, "dfthcsos"))):
        zf.write(os.path.join(root, "dfthcsos", name), f"dfthcsos/{name}")

expected_sums = {rel: sums[rel] for rel in sums}
with zipfile.ZipFile(REBUILT) as zf:
    rebuilt_names = zf.namelist()
    assert zf.testzip() is None
    assert sorted(rebuilt_names) == sorted(expected_sums), "member list differs"
    for rel, expected in sorted(expected_sums.items()):
        got = hashlib.sha256(zf.read(rel)).hexdigest()
        assert got == expected, (rel, got, expected)

print("REBUILT ARCHIVE VERIFIED:", REBUILT, os.path.getsize(REBUILT), "bytes")
print("members:", rebuilt_names)

# Reported component scores (official verifier, default salt).
invsqrt_cost = 78765.63681893334
dqi_cost = 360209905486.0
chem_cost = 295363118.60829234
ref = {"invsqrt": 2076774.23, "dqi": 24439463583672.93, "chemistry": 3355599588.32}
ratios = [ref["invsqrt"] / invsqrt_cost, ref["dqi"] / dqi_cost, ref["chemistry"] / chem_cost]
gm = (ratios[0] * ratios[1] * ratios[2]) ** (1 / 3)
print("ratios:", [round(r, 6) for r in ratios])
print("expected geometric mean:", round(gm, 5))
print("public leaderboard score: 27.28983 (submission 58313675)")
print("components: invsqrt 4560ac0c (ahoirg 64-row), DQI 821bf8d1 (areebbb cutoff-18 retained), chemistry baa99712 (maoxin123 coded-word 4044 loaders)")
