# %% [markdown]
# # QCC | milestone portfolio — public repro (C11, public-best stack)
#
# Assembles and verifies our three-task submission for
# [Google Quantum AI - Verifiable Quantum Circuit Compilation](https://www.kaggle.com/competitions/google-verifiable-quantum-circuit-compilation).
#
# **Files** come from the public dataset [`hayatohikawa/qcc-c8-milestone-portfolio`](https://www.kaggle.com/datasets/hayatohikawa/qcc-c8-milestone-portfolio)
# (all components Apache-2.0 with NOTICE files kept alongside — see its `CREDITS.md`).
#
# The notebook:
#
# 1. loads `invsqrt.kmb`, `dqi.kmb` and the 15 `dfthcsos/angle_k_*.kmb` + `submission.npz`,
# 2. runs the **competition's official verifiers** on each task (competition data is attached),
# 3. writes `submission.zip` in the exact layout the leaderboard expects.
#
# Local official-verifier results (the same ones this notebook re-runs):
#
# | task | score | notes |
# |---|---|---|
# | invsqrt | 75038.75284622009 | 44 qubits, worst err/tol 0.9912 (Syed v13 + jeff q28 AND merges + Leo Tang q27 AND merge) |
# | dqi | 347375470571.73334 | 890 qubits (Syed line + our product retention + 暗黑AGI HW-27 native patch) |
# | dfthcsos | 294762732.97757906 | λ_eff 46.921618411132954, T 14712, Q 427 (marculera + 暗黑AGI refit) |
# | **GM** | **≈ 28.091** | geometric mean of ref/cost over the three tasks |
#
# Public leaderboard: the exact files in this notebook are submission C11 (see the competition
# submissions page; C10 = same dqi/chem with the Atakan/Asterios invsqrt scored 28.08046).
# Prior: C9 28.07504, C8 28.06404 (ref 58397138, earlier dataset versions).

# %%
import glob
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

WORK = Path("/kaggle/working")

# Locate the portfolio dataset (mounted under /kaggle/input/datasets/<owner>/<slug>/)
candidates = []
for p in glob.glob("/kaggle/input/**/CREDITS.md", recursive=True):
    candidates.append(Path(p).parent)
for p in glob.glob("/kaggle/input/**/invsqrt.kmb", recursive=True):
    candidates.append(Path(p).parent)
candidates = sorted(set(candidates), key=lambda d: (not (d / "invsqrt.kmb").exists(), len(str(d))))
print("dataset candidates:", candidates)
DATA = next(
    (d for d in candidates
     if (d / "invsqrt.kmb").exists() or (d / "CREDITS.md").exists()),
    None,
)
if DATA is None:
    import subprocess as _sp
    _sp.run(["find", "/kaggle/input", "-maxdepth", "5"], check=False)
    raise SystemExit("portfolio dataset not found under /kaggle/input")
print("dataset:", DATA)
assert (DATA / "invsqrt.kmb").exists(), sorted(p.name for p in DATA.iterdir())

VERIFIERS = None
for cand in (
    Path("/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation/verifiers"),
    Path("/kaggle/input/google-verifiable-quantum-circuit-compilation/verifiers"),
    Path("/kaggle/input/google-verifiable-quantum-circuit-compilation"),
):
    if (cand / "dfthcsos").exists():
        VERIFIERS = cand
        break
if VERIFIERS is None:
    found = next(
        (Path(p) for p in glob.glob("/kaggle/input/**/dfthcsos/verify.py", recursive=True)),
        None,
    )
    VERIFIERS = found.parent if found else None
print("verifiers:", VERIFIERS)
assert VERIFIERS is not None, "attach the competition data (verifiers)"

# kickmix (the competition's circuit simulator) lives beside the verifiers
for kick in (
    VERIFIERS.parent / "kickmix",
    Path("/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation/kickmix"),
):
    if kick.exists() and str(kick) not in sys.path:
        sys.path.insert(0, str(kick))
        print("kickmix path:", kick)
import kickmix  # noqa: F401  (fails fast if the .so is missing)

# verifiers import each other as top-level packages; subprocesses need PYTHONPATH
KICK_DIR = next(
    (p for p in (
        Path("/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation/kickmix"),
        VERIFIERS.parent / "kickmix",
    ) if p.exists()),
    None,
)
env = os.environ.copy()
paths = [str(VERIFIERS)]
if KICK_DIR:
    paths.insert(0, str(KICK_DIR))
env["PYTHONPATH"] = os.pathsep.join(paths + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
print("PYTHONPATH:", env["PYTHONPATH"])

# %% [markdown]
# ## 1. Stage the submission files

# %%
# Stage files into /kaggle/working (copy: /kaggle/input is a different device)
sub = WORK / "sub"
sub.mkdir(parents=True, exist_ok=True)
import shutil as _sh

for name in ("invsqrt.kmb", "dqi.kmb"):
    dst = sub / name
    if not dst.exists():
        _sh.copy2(DATA / name, dst)
        print("staged", name, dst.stat().st_size)

import tarfile

chem_dst = sub / "dfthcsos"
if not chem_dst.exists():
    if (DATA / "dfthcsos").is_dir():
        _sh.copytree(DATA / "dfthcsos", chem_dst)
    else:
        with tarfile.open(DATA / "dfthcsos.tar") as tf:
            tf.extractall(sub)
assert (chem_dst / "submission.npz").exists(), sorted(p.name for p in chem_dst.glob("*"))
print("chem loaders:", sorted(p.name for p in chem_dst.glob("angle_k_*.kmb"))[:3], "...")

lic_dst = DATA / "licenses"
if not lic_dst.exists() and (DATA / "licenses.tar").exists():
    lic_dst = WORK / "licenses"
    with tarfile.open(DATA / "licenses.tar") as tf:
        tf.extractall(WORK)

# %% [markdown]
# ## 2. Official verification
#
# Each cell runs the competition's unchanged verifier and checks `status == "PASS"`.

# %%


def run_verify(cmd, cwd, expect_keys=()):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=7200, env=env)
    out = r.stdout + r.stderr
    payload = None
    # pretty-printed JSON object: find the last top-level '{' and decode from there
    dec = json.JSONDecoder()
    for i, ch in enumerate(out):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(out[i:])
                if isinstance(obj, dict) and "status" in obj:
                    payload = obj
            except json.JSONDecodeError:
                continue
    if payload is None:
        tail = "\n".join(out.splitlines()[-60:])
        raise RuntimeError(f"no JSON receipt:\n{tail}")
    print(json.dumps(payload, indent=1, default=str)[:2000])
    assert payload.get("status") == "PASS", payload
    for k in expect_keys:
        assert k in payload, payload
    return payload


py = sys.executable

inv = run_verify(
    [py, "invsqrt/verify_submission_invsqrt.py", str(sub / "invsqrt.kmb"),
     "--shots-per-x", "1", "--batch-size", "12"],
    cwd=VERIFIERS,
)
print("invsqrt cost:", inv["score"])

# %%


def dqi_verify(salt=None):
    cmd = [py, "dqi/verify_submission_dqi.py", str(sub / "dqi.kmb"), "--max-workers", "4"]
    if salt:
        cmd += ["--salt", salt]
    return run_verify(cmd, cwd=VERIFIERS)


dqi0 = dqi_verify(None)
dqi1 = dqi_verify("br2s2")
print("dqi scores:", dqi0["score"], dqi1["score"],
      "errors:", dqi0.get("value_errors"), dqi0.get("phase_errors"),
      dqi1.get("value_errors"), dqi1.get("phase_errors"))

# %%


chem = run_verify([py, "dfthcsos/verify.py", str(sub / "dfthcsos")], cwd=VERIFIERS)
print("chem score:", chem["score"], "lambda_eff:", chem["lambda_eff"])

# %% [markdown]
# ## 3. Geometric mean (same formula as `Evaluation.md`)

# %%
BASE = {"invsqrt": 78765.64 * 26.37, "dqi": 3.6095e11 * 67.71, "dfthcsos": 2.95131e8 * 11.37}
dqi_cost = (dqi0["score"] + dqi1["score"]) / 2.0
ratios = {
    "invsqrt": BASE["invsqrt"] / inv["score"],
    "dqi": BASE["dqi"] / dqi_cost,
    "dfthcsos": BASE["dfthcsos"] / chem["score"],
}
gm = (ratios["invsqrt"] * ratios["dqi"] * ratios["dfthcsos"]) ** (1 / 3)
print(json.dumps({"ratios": ratios, "estimated_GM": gm}, indent=1))

# %% [markdown]
# ## 4. Package `submission.zip`

# %%
zip_path = WORK / "submission.zip"
if zip_path.exists():
    zip_path.unlink()
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    z.write(sub / "invsqrt.kmb", "invsqrt.kmb")
    z.write(sub / "dqi.kmb", "dqi.kmb")
    for p in sorted((sub / "dfthcsos").glob("angle_k_*.kmb"),
                    key=lambda p: int("".join(filter(str.isdigit, p.stem)))):
        z.write(p, f"dfthcsos/{p.name}")
    z.write(sub / "dfthcsos" / "submission.npz", "dfthcsos/submission.npz")
    z.write(DATA / "CREDITS.md", "CREDITS.md")
    lic = lic_dst
    if lic.exists():
        for p in sorted(lic.iterdir()):
            if p.name.startswith("._"):
                continue
            z.write(p, f"licenses/{p.name}")
print("wrote", zip_path, zip_path.stat().st_size, "bytes")
with zipfile.ZipFile(zip_path) as z:
    print("\n".join(z.namelist()))

# %% [markdown]
# Upload `submission.zip` to the competition (Submissions → Upload), or run:
#
# ```bash
# kaggle competitions submit -c google-verifiable-quantum-circuit-compilation \
#     -f /kaggle/working/submission.zip -m "C11 public repro"
# ```
#
# ### Licence summary (full text in `licenses/`)
#
# - `invsqrt.kmb`: Syed Asad Ali (Apache-2.0); AND-merge cuts by jeff emerson (q28) and Leo Tang (q27).
# - `dqi.kmb`: Syed Asad Ali 890-qubit decoder line (Apache-2.0); our product-retention pass;
#   HW-27 measure-first identity credited to manwithacat / Kirill Tymchishin / Md. Hamid Hosen;
#   native patch by boristown (team 暗黑AGI).
# - `dfthcsos/`: Lera / marculera table + loaders (Apache-2.0) with weights refitted by boristown
#   (team 暗黑AGI, Schur-nullspace L-BFGS).
