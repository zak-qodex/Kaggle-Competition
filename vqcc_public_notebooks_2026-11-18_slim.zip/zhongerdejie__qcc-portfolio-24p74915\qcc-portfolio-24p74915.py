#!/usr/bin/env python
"""Reproduce the QCC portfolio at public score 24.74915 from PUBLIC parts.

Components (all Apache-2.0, no private data):
  * invsqrt af469847 + dqi 993c7038  <- somejoint/qcc-ladder-parts
  * dfthcsos soft-word loaders        <- iwanttorungemma9b/vqcc-dfthc-soft-word-loaders
  * kickmix engine + official verifiers <- competition data

Run:  python qcc_portfolio_24p74915.py
"""
import json
import math
import os
import pathlib
import shutil
import subprocess
import sys
import zipfile

INPUT = pathlib.Path("/kaggle/input")
WORK = pathlib.Path("/kaggle/working")


def find_one(pattern):
    hits = sorted(INPUT.rglob(pattern))
    if not hits:
        raise FileNotFoundError(f"not found in /kaggle/input: {pattern}")
    return hits[0]


def parse_json(text):
    i = text.find("{")
    if i < 0:
        raise ValueError("no JSON object in output")
    obj, _ = json.JSONDecoder().raw_decode(text[i:])
    return obj


def main():
    invsqrt = find_one("invsqrt-af469847/invsqrt-af469847/invsqrt.kmb")
    dqi = find_one("dqi-993c7038/dqi-993c7038/dqi.kmb")
    chem_src = find_one("submission/dfthcsos/submission.npz").parent
    kickmix_so = find_one("kickmix/kickmix.so")
    verifiers = find_one("verifiers/invsqrt/verify_submission_invsqrt.py").parent.parent

    print("invsqrt :", invsqrt)
    print("dqi     :", dqi)
    print("chem    :", chem_src)
    print("kickmix :", kickmix_so)
    print("verifier:", verifiers)

    out = WORK / "submission"
    if out.exists():
        shutil.rmtree(out)
    (out / "dfthcsos").mkdir(parents=True)
    shutil.copy(invsqrt, out / "invsqrt.kmb")
    shutil.copy(dqi, out / "dqi.kmb")
    for f in sorted(chem_src.glob("angle_k_*.kmb")):
        shutil.copy(f, out / "dfthcsos" / f.name)
    shutil.copy(chem_src / "submission.npz", out / "dfthcsos" / "submission.npz")

    archive = WORK / "submission.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as zf:
        zf.write(out / "invsqrt.kmb", "invsqrt.kmb")
        zf.write(out / "dqi.kmb", "dqi.kmb")
        for f in sorted((out / "dfthcsos").glob("angle_k_*.kmb")):
            zf.write(f, f"dfthcsos/{f.name}")
        zf.write(out / "dfthcsos" / "submission.npz", "dfthcsos/submission.npz")
    print("assembled:", archive, archive.stat().st_size, "bytes")

    env = dict(os.environ)
    env["PYTHONPATH"] = str(kickmix_so.parent) + os.pathsep + env.get("PYTHONPATH", "")
    env["LD_LIBRARY_PATH"] = str(kickmix_so.parent) + os.pathsep + env.get("LD_LIBRARY_PATH", "")

    def run(name, script, target):
        cmd = [sys.executable, str(verifiers / script), str(target)]
        print("\n$", " ".join(cmd), flush=True)
        r = subprocess.run(cmd, env=env, capture_output=True, text=True)
        print(r.stdout[-3000:], flush=True)
        if r.returncode != 0:
            print(r.stderr[-2000:])
            raise SystemExit(f"{name} verification FAILED")
        return parse_json(r.stdout)

    inv = run("invsqrt", "invsqrt/verify_submission_invsqrt.py", out / "invsqrt.kmb")
    dq = run("dqi", "dqi/verify_submission_dqi.py", out / "dqi.kmb")
    ch = run("dfthcsos", "dfthcsos/verify.py", out / "dfthcsos")

    REF = {"invsqrt": 2076774.233715282, "dqi": 24439473914136.668,
           "dfthcsos": 3355599588.3155365}
    costs = {"invsqrt": inv["score"], "dqi": dq["score"], "dfthcsos": ch["score"]}
    gains = {k: REF[k] / v for k, v in costs.items()}
    score = math.prod(gains.values()) ** (1 / 3)
    print("\n==== RESULT ====", flush=True)
    print(json.dumps({"costs": costs, "gains": gains, "geometric_score": score}, indent=2))
    (WORK / "result.json").write_text(json.dumps(
        {"costs": costs, "gains": gains, "geometric_score": score}, indent=2))


if __name__ == "__main__":
    main()
