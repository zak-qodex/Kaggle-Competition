"""Matched-input diagnosis of the single public-distribution holdout failure.

No new circuit or seed search. The baseline uses the candidate's predeclared
holdout seed so error patterns, classical masks and simulator seeds match.
"""
from pathlib import Path
import os,sys,hashlib,json,zipfile,shutil,gc
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
ROOT=Path('/kaggle/working');INPUT=Path('/kaggle/input')
COMP=next(p for p in INPUT.rglob('verify_submission_dqi.py') if 'verifiers/dqi' in str(p)).parents[2]
sys.path[:0]=[str(COMP/'kickmix'),str(COMP/'verifiers/dqi')]
import kickmix as km
import verify_submission_dqi as DV
import numpy as np
BASE_SHA='aeb546a0da98af1f7ce0d83f9e6d5c6dd5db5f4491caf80c47228fb260d048af'
CAND_SHA='feac739bdc97863291e4b7f5aad3afe5222eb5306b0d5d7180a49fbfa1137391'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
zpath=next(p for p in INPUT.rglob('submission.zip') if digest(p)==BASE_SHA)
with zipfile.ZipFile(zpath) as z:
 with z.open('dqi.kmb') as a,(ROOT/'baseline.kmb').open('wb') as b:shutil.copyfileobj(a,b)
candidate=next(p for p in INPUT.rglob('dqi-workspace.kmb') if digest(p)==CAND_SHA)
seed=DV._initial_seed(CAND_SHA,'vqcc-workspace-reuse-holdout-20261025')
spec=DV.ProblemSpecDQI.benchmark_instance()
original_parallel=DV._run_parallel
failure_dir=ROOT/'failed_batches';failure_dir.mkdir(exist_ok=True)
def instrumented(fn,tasks,max_workers):
 def wrapped(task):
  result=fn(task)
  if result[0]+result[1]:
   (failure_dir/f'{task[0]}.json').write_text(json.dumps({'task':task,'value_errors':result[0],'phase_errors':result[1]}))
  return result
 return original_parallel(wrapped,tasks,max_workers)
DV._run_parallel=instrumented
base=km.Circuit.from_file(str(ROOT/'baseline.kmb'),format='kmb')
print('Starting full matched-input baseline verifier',flush=True)
report=DV.verify(base,spec,seed=seed,max_workers=4)
(ROOT/'baseline_matched_holdout.json').write_text(json.dumps(report,indent=2))
failed=[json.loads(p.read_text()) for p in sorted(failure_dir.glob('*.json'))]
print('Matched baseline:',report['phase_errors'],'phase errors; failed batches',len(failed),flush=True)
weights=DV.optimal_dqi_weights(spec.m,spec.max_errors,spec.degree,spec.r)**2
tables=DV.FieldTables(km.GF2Field(spec.degree))
def reproduce(circuit,task):
 start,rng_seed,sim_seed=task
 syndromes,mbuc,phases=DV.sample_shots(spec,tables,np.random.default_rng(rng_seed),256,weights)
 q,c,a=DV.validate_registers(circuit,spec)
 sim=km.Simulator(batch_size=256,debug_print=False,counting_operations=True,seed=sim_seed)
 sim.use_same_registers_as(circuit)
 inputs=DV.to_bits(syndromes,spec.degree)
 sim.write_across_shots(km.array(q),inputs)
 sim.write_across_shots(km.array(c),DV.to_bits(mbuc,spec.degree))
 sim.do(circuit)
 value=(sim.read_across_shots(km.array(q))^inputs).any(axis=0)
 if a:value|=sim.read_across_shots(km.array(a)).any(axis=0)
 bad=(sim.read_phase_flipped_across_shots()^phases)&~value
 result={'batch_start':start,'value_failure_indices':(np.flatnonzero(value)+start).tolist(),'phase_failure_indices':(np.flatnonzero(bad)+start).tolist()}
 examples=[{'index':int(start+i),'syndromes':syndromes[i].tolist(),'measurement_masks':mbuc[i].tolist(),'expected_phase':bool(phases[i])} for i in np.flatnonzero(bad)]
 return result,examples
base_cases=[];examples=[]
for f in failed:
 row,e=reproduce(base,f['task']);base_cases.append(row);examples+=e
assert sum(len(r['phase_failure_indices']) for r in base_cases)==report['phase_errors']
del base;gc.collect()
new=km.Circuit.from_file(str(candidate),format='kmb')
candidate_cases=[reproduce(new,f['task'])[0] for f in failed]
assert base_cases==candidate_cases,(base_cases,candidate_cases)
result={'baseline_full_report':report,'matched_failure_batches':failed,'baseline_cases':base_cases,'candidate_cases':candidate_cases,'same_failure_inputs':True,'candidate_holdout_full_phase_errors':1,'diagnosis':'The source decoder fails on the same held-out input. No new failure was introduced by workspace reuse on this test.','test_policy':'Single predeclared holdout reused for diagnosis, not seed selection.'}
(ROOT/'matched_holdout_receipt.json').write_text(json.dumps(result,indent=2))
(ROOT/'synthetic_failure_examples.json').write_text(json.dumps(examples,indent=2))
print('PASS: source and candidate fail on identical held-out input',json.dumps(base_cases),flush=True)
