# QCC public frontier 25.405 — verified portfolio
# Kaggle notebook: verifies every published member against SHA256SUMS and
# rebuilds submission.zip with exactly the submitted layout. No internet needed.

import hashlib
import os
import shutil
import zipfile

DATASET = "/kaggle/input/qcc-public-frontier-25-405"
WORK = "/kaggle/working"
REBUILT = os.path.join(WORK, "submission.zip")

print("dataset files:", sorted(os.listdir(DATASET)))

# 1. Read the published manifest.
sums = {}
with open(os.path.join(DATASET, "SHA256SUMS")) as fh:
    for line in fh:
        line = line.strip()
        if not line:
            continue
        digest, path = line.split(None, 1)
        sums[path.lstrip("./")] = digest
print(f"manifest entries: {len(sums)}")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# 2. Kaggle may auto-extract an uploaded archive. Support both layouts:
#    a stored submission.zip, or the extracted submission/ directory.
archive = os.path.join(DATASET, "submission.zip")
if os.path.isfile(archive):
    print("using stored archive:", archive, os.path.getsize(archive), "bytes")
    with zipfile.ZipFile(archive) as zf:
        print("archive members:", len(zf.namelist()))
        assert zf.testzip() is None
        zf.extractall(os.path.join(WORK, "verify"))
    root = os.path.join(WORK, "verify")
else:
    print("no submission.zip in dataset; using extracted files")
    root = DATASET
    if os.path.isdir(os.path.join(DATASET, "submission")):
        root = os.path.join(DATASET, "submission")

# 3. Verify every member.
bad = []
missing = []
for rel, expected in sorted(sums.items()):
    path = os.path.join(root, rel)
    if not os.path.isfile(path):
        missing.append(rel)
        continue
    got = sha256(path)
    if got != expected:
        bad.append((rel, got, expected))
print("missing:", missing)
print("hash mismatches:", bad[:5], "count", len(bad))
assert not missing and not bad
print("ALL 18 MEMBER HASHES VERIFIED")

# 4. Rebuild the archive exactly as the submitted one.
if os.path.exists(REBUILT):
    os.remove(REBUILT)
with zipfile.ZipFile(REBUILT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    zf.write(os.path.join(root, "invsqrt.kmb"), "invsqrt.kmb")
    zf.write(os.path.join(root, "dqi.kmb"), "dqi.kmb")
    for name in sorted(os.listdir(os.path.join(root, "dfthcsos"))):
        zf.write(os.path.join(root, "dfthcsos", name), f"dfthcsos/{name}")

# 5. Re-verify the rebuilt archive.
expected_sums = {rel: sums[rel] for rel in sums}
with zipfile.ZipFile(REBUILT) as zf:
    rebuilt_names = zf.namelist()
    assert zf.testzip() is None
    assert sorted(rebuilt_names) == sorted(expected_sums), "member list differs"
    for rel, expected in sorted(expected_sums.items()):
        got = hashlib.sha256(zf.read(rel)).hexdigest()
        assert got == expected, (rel, got, expected)

print("REBUILT ARCHIVE VERIFIED:", REBUILT, os.path.getsize(REBUILT), "bytes")
print("members:", rebuilt_names)

# 6. Reported component scores (official verifier, default salt).
invsqrt_cost = 93555.26267586512
dqi_cost = 373534939340.6408
chem_cost = 297237044.9509761
ref = {"invsqrt": 2076774.23, "dqi": 24439463583672.93, "chemistry": 3355599588.32}
ratios = [ref["invsqrt"] / invsqrt_cost, ref["dqi"] / dqi_cost, ref["chemistry"] / chem_cost]
gm = (ratios[0] * ratios[1] * ratios[2]) ** (1 / 3)
print("ratios:", [round(r, 6) for r in ratios])
print("expected geometric mean:", round(gm, 5))
print("public leaderboard score: 25.40482 (submission 58274289)")
