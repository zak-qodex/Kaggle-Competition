"""Kaggle worker: build dfthcsos ANGLE circuits from a factorization npz and run the official verifier.

Env/args are fixed by editing CONFIG below before each push. Outputs /kaggle/working/dfthcsos/ and result.json.
"""
import glob
import json
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np

CONFIG = json.loads(Path(__file__).with_name("config.json").read_text()) if Path(__file__).with_name("config.json").exists() else None
if CONFIG is None:
    CONFIG = {"fact": "m13_b8_v2.npz", "J": None, "addr": 2}

COMP = Path(next(iter(glob.glob("/kaggle/input/**/google-verifiable-quantum-circuit-compilation", recursive=True))))
WORK_DS = Path(next(iter(glob.glob("/kaggle/input/**/qcc-work", recursive=True))))
sys.path.insert(0, str(COMP / "kickmix"))
sys.path.insert(0, str(COMP / "verifiers"))
sys.path.insert(0, str(WORK_DS / "src"))
import kickmix as km  # noqa: E402
import angles_qrom as AQ  # noqa: E402

OUT = Path("/kaggle/working/dfthcsos")
shutil.rmtree(OUT, ignore_errors=True)
OUT.mkdir(parents=True)
t0 = time.time()
z = np.load(WORK_DS / "fact" / CONFIG["fact"], allow_pickle=False)
params = {k: np.array(z[k]) for k in z.files}
brot = int(params["brot"])
edges = params["tree_edges"].astype(np.int64)
words = AQ.canonical_words(params["angle_words"], edges, brot)
ADDR = int(CONFIG.get("addr", 4))
J = int(CONFIG.get("J") or AQ.max_batch(brot, len(words), ADDR))
deltas = AQ.batch_deltas(words, J)
reports = []
for k, d in enumerate(deltas):
    c, rep = (AQ.build if ADDR == 4 else AQ.build2)(d, brot, return_report=True)
    c.to_file(str(OUT / f"angle_k_{k}.kmb"), format="kmb")
    reports.append(rep)
    print(k, rep["num_qubits"], rep["static_toffoli"], flush=True)
sub = {k: params[k] for k in ("U", "W", "H2_I", "H1_I", "Hsym_lower", "tree_edges")}
np.savez(OUT / "submission.npz", **sub)
print("built", len(deltas), "circuits in", round(time.time() - t0), "s; static toffoli/pass", sum(r["static_toffoli"] for r in reports))
from dfthcsos.verify import verify  # noqa: E402
res = verify(str(OUT))
res["build_seconds"] = round(time.time() - t0)
res["J"] = J
res["brot"] = brot
Path("/kaggle/working/result.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps({k: res[k] for k in ("status", "score", "lambda_eff", "toffoli_count", "num_qubits") if k in res}, default=str))
