# PUBLIC REPRODUCTION with credit: Original by pramitdas - qcc-public-frontier-28-1277-verified-portfolio
# Original: https://www.kaggle.com/code/pramitdas/qcc-public-frontier-28-1277-verified-portfolio
# This is a reproduction (not original work). Submitted from the private reproduction kernel, it scored 28.12769 on the public leaderboard (submission 58444446, AI OKAJIMA).
# This public kernel is for transparency/credit only and is not used for submissions.
#
# REPRODUCTION with credit: byte-identical transport of pramitdas/qcc-public-frontier-28-1277-verified-portfolio
# (https://www.kaggle.com/code/pramitdas/qcc-public-frontier-28-1277-verified-portfolio), verified: author LB 28.12769 rank 103,
# author submission 58440434 documented in notebook, 58-team LB cluster at exactly 28.12769 ranks 84-141,
# asteriospanoras re-verification notebook also documents the same portfolio scoring 28.1277.
# Components: invsqrt 0af21cb8 maoxin123, DQI 66b4f18b Balram Srinivasan, chemistry npz 703843d3 Atakan Aldemir on marculera loaders.
# Code below is unchanged from the original apart from this credit header.
#
# QCC public frontier 28.1277 - verified portfolio
#
# This is the best-of-public stack as of 2026-11-16: the single cheapest verified
# public circuit for each of the three tasks, adopted byte-for-byte. Nothing in
# this notebook is original circuit work; every author is named below.
#
# The kernel verifies every published member against SHA256SUMS and rebuilds
# submission.zip with exactly the submitted layout. No internet needed.

import hashlib
import os
import zipfile

WORK = "/kaggle/working"
REBUILT = os.path.join(WORK, "submission.zip")

print("INPUT DIRS:", sorted(os.listdir("/kaggle/input")) if os.path.isdir("/kaggle/input") else "NO INPUT")

DATASET = None
for rootdir, dirs, files in os.walk("/kaggle"):
    if "SHA256SUMS" in files:
        DATASET = rootdir
        break
if DATASET is None:
    for rootdir, dirs, files in os.walk("/kaggle"):
        if "submission.zip" in files:
            DATASET = rootdir
            break
assert DATASET is not None, "no dataset found under /kaggle"
print("dataset dir:", DATASET)
print("dataset files:", sorted(os.listdir(DATASET)))

sums = {}
with open(os.path.join(DATASET, "SHA256SUMS")) as fh:
    for line in fh:
        line = line.strip()
        if not line:
            continue
        digest, path = line.split(None, 1)
        sums[path.lstrip("./")] = digest
print(f"manifest entries: {len(sums)}")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


archive = os.path.join(DATASET, "submission.zip")
if os.path.isfile(archive):
    print("using stored archive:", archive, os.path.getsize(archive), "bytes")
    with zipfile.ZipFile(archive) as zf:
        print("archive members:", len(zf.namelist()))
        assert zf.testzip() is None
        zf.extractall(os.path.join(WORK, "verify"))
    root = os.path.join(WORK, "verify")
else:
    print("no submission.zip in dataset; using extracted files")
    root = DATASET
    if os.path.isdir(os.path.join(DATASET, "submission")):
        root = os.path.join(DATASET, "submission")

bad = []
missing = []
for rel, expected in sorted(sums.items()):
    path = os.path.join(root, rel)
    if not os.path.isfile(path):
        missing.append(rel)
        continue
    got = sha256(path)
    if got != expected:
        bad.append((rel, got, expected))
print("missing:", missing)
print("hash mismatches:", bad[:5], "count", len(bad))
assert not missing and not bad
print("ALL 18 MEMBER HASHES VERIFIED")

if os.path.exists(REBUILT):
    os.remove(REBUILT)
with zipfile.ZipFile(REBUILT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    zf.write(os.path.join(root, "invsqrt.kmb"), "invsqrt.kmb")
    zf.write(os.path.join(root, "dqi.kmb"), "dqi.kmb")
    for name in sorted(os.listdir(os.path.join(root, "dfthcsos"))):
        zf.write(os.path.join(root, "dfthcsos", name), f"dfthcsos/{name}")

with zipfile.ZipFile(REBUILT) as zf:
    rebuilt_names = zf.namelist()
    assert zf.testzip() is None
    assert sorted(rebuilt_names) == sorted(sums), "member list differs"
    for rel, expected in sorted(sums.items()):
        got = hashlib.sha256(zf.read(rel)).hexdigest()
        assert got == expected, (rel, got, expected)

print("REBUILT ARCHIVE VERIFIED:", REBUILT, os.path.getsize(REBUILT), "bytes")
print("members:", rebuilt_names)

# Official verifier output, default (empty) salt.
invsqrt_cost = 74797.36535717871
dqi_cost = 347128304010.8116
chem_cost = 294762512.8596263
ref = {"invsqrt": 2076774.233715282, "dqi": 24439463583672.93, "chemistry": 3355599588.3155365}
ratios = [ref["invsqrt"] / invsqrt_cost, ref["dqi"] / dqi_cost, ref["chemistry"] / chem_cost]
gm = (ratios[0] * ratios[1] * ratios[2]) ** (1 / 3)
print("ratios:", [round(r, 6) for r in ratios])
print("expected geometric mean:", round(gm, 5))
print("public leaderboard score: 28.1277 (submission 58440434)")
print()
print("invsqrt  0af21cb8  maoxin123 v27              44 q, 1,699.9401 Toffoli-equiv, 200,540,928 shots PASS")
print("dqi      66b4f18b  Balram Srinivasan 28.10    890 q, 367,877.55 Toffolis, 0 failures")
print("dfthcsos 703843d3  Atakan Aldemir             427 q, T=14,712, lambda_eff 46.92158337179646")
